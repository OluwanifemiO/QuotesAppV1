﻿$(document).ready(function () {
    let _quoteItemsList = $('#quoteItemsList');
    let _listItemsMsg = $('#listItemsMsg');
    let _addNewItemMsg = $('#addNewItemMsg');
    let allTagsBtn = $('#allTagsBtn');
    let heading = $('#heading');
    let formHeading = $('#QuoteHeading');
    let quoteForm = $('#quoteForm');
    let editQuoteForm = $('#editQuoteForm');
    let mostLikedQuotesBtn = $('#mostLikedQuotesBtn');
    let _userInputMostLikedCount = $('#userInputMostLiked');
    let otherItemsList = $('#otherItemsList');

    let _quotesUrl = 'https://localhost:7086/api/quotes';
    let _tagsUrl = 'https://localhost:7086/api/tags';


    //view quote by id click listener
    function quoteByIdClickListener() {
        $('.quoteLink').on('click', function () {
            // Handle click event, e.g., display details of the clicked quote
            let quoteId = $(this).data('quoteid');

            _quoteItemsList.hide();
            otherItemsList.show();
            otherItemsList.empty();

            loadQuoteById(quoteId);
        });
    }


    //view all quotes button
    function allQuotesClickListener() {
        $('#allQuotesBtn').on('click', function () {
            // Handle click event, e.g., display details of the clicked quote'
            otherItemsList.empty();
            otherItemsList.hide();
            _quoteItemsList.show();
            loadQuotes();
        });
    }

    //view all tags button
    function allTagsClickListener() {
        $('#allTagsBtn').on('click', function () {
            // Handle click event, e.g., display details of the clicked quote'
            _quoteItemsList.hide();
            otherItemsList.show();
            otherItemsList.empty();

            loadTags();
        });
    }

    //view most liked quotes button
    function mostLikedClickListener() {
        $('#mostLikedQuotesBtn').on('click', function () {
            let count = _userInputMostLikedCount.val();
            if (count < 1) {
                _listItemsMsg.text("Please enter a valid number greater than 0");
                return;
            }
            _quoteItemsList.hide();
            otherItemsList.show();
            otherItemsList.empty();
            mostLikedQuotes(count);
        });
    }


    //a function to get all quotes from the api
    let loadQuotes = async function () {
        let resp = await fetch(_quotesUrl, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let quotes = await resp.json();

            if (quotes.length > 0) {
                //empty the list
                _quoteItemsList.empty();
                // Loop through the quotes array and append the details to the list 
                for (let i = 0; i < quotes.length; i++) {

                    let listItem = $('<li>');
                    let quoteLink = $('<a>')
                        .attr('class', 'quoteLink')
                        .attr('data-quoteid', quotes[i].quoteId)
                        .attr('style', 'cursor: pointer; color: blue;')
                        .text('(ID: ' + quotes[i].quoteId + ')');

                    let tagButton = $('<button>')
                        .attr('type', 'button')
                        .attr('class', 'btn btn-primary tagQuoteBtn')
                        .attr('data-quoteid', quotes[i].quoteId)
                        .text('Tag Quote');

                    let editButton = $('<button>')
                        .attr('type', 'button')
                        .attr('class', 'btn btn-primary editQuoteBtn')
                        .attr('data-quoteid', quotes[i].quoteId)
                        .text('Edit Quote');

                    let likeButton = $('<button>')
                        .attr('type', 'button')
                        .attr('class', 'btn btn-primary')
                        .attr('id', 'likeQuoteBtn')
                        .attr('data-quoteid', quotes[i].quoteId)
                        .text('Like Quote');

                    listItem.append(quoteLink);
                    listItem.append('<strong> The quote: </strong> ' + quotes[i].content + ' is by <strong> ' + quotes[i].author +
                        '</strong>. Likes: ' + quotes[i].likes + '. Tags: #');

                    //loop through the tag names array
                    for (let j = 0; j < quotes[i].tagNames.length; j++) {

                        listItem.append('<i>' + quotes[i].tagNames[j] + '</i>');

                        if (j < quotes[i].tagNames.length - 1) {
                            listItem.append(', #');
                        }
                    }

                    _quoteItemsList.append(listItem);
                    _quoteItemsList.append(tagButton);
                    _quoteItemsList.append('<span></span> <span></span>');
                    _quoteItemsList.append(editButton);
                    _quoteItemsList.append('<span> </span>');
                    _quoteItemsList.append(likeButton);
                    _quoteItemsList.append('<span> </span>');
                    _quoteItemsList.append('</br> </br>');

                }


                // Add a click event listener to the quote links
                quoteByIdClickListener();

            }
            else {
                _listItemsMsg.text('There aren\'t any quotes. Use the form to add some.');
            }

        }
        else {
            _listItemsMsg.text('There was a problem loading the quotes.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }
    };


    //a function to get quote by id from the api
    let loadQuoteById = async function (id) {
        let resp = await fetch(`https://localhost:7086/api/quotes/${id}`, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let quote = await resp.json();

            if (quote != null) {
                // Update the details in the existing list item

                let listItem = $('<li>');

                listItem.append('(ID: ' + quote.quoteId + ') </br> <strong> The quote content: </strong> ' + quote.content + ' </br>  <strong> Author: </strong>' + quote.author
                    + '. </br> <strong>Likes: </strong>' + quote.likes + '. </br>' + '<strong>Tags: </strong> #');

                for (let j = 0; j < quote.tagNames.length; j++) {

                    listItem.append('' + quote.tagNames[j]);

                    if (j < quote.tagNames.length - 1) {
                        listItem.append(', #');
                    }
                }

                otherItemsList.append(listItem);
                otherItemsList.append('</br> <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button> </br> </br>');
            }
            else {
                _listItemsMsg.text('There isn\'t any quote by that id. Use the form to add one.');
            }

            allQuotesClickListener();

        }
        else {
            _listItemsMsg.text('There was a problem loading the quote.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }
    };

    $('#quoteByTagBtn').on('click', function () {

        _quoteItemsList.hide();
        otherItemsList.show();
        otherItemsList.empty();

        otherItemsList.append(`
            <div class="tagForQuote">
                <label for="tag">Enter Tag:</label>
                <input type="text" id="tag" name="tag" class="form-control" />
            </div>

            </br>

            <button type="button" id="findQuoteBtn" class="btn btn-primary">Find Quotes</button>
            <span> </span> <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button>

            </br>

            <div id="quotes">
            </div>
        `);

        allQuotesClickListener();
    });

    //function to get quotes by tag
    $(document).on('click', '#findQuoteBtn', async function () {
        let tagName = $('#tag').val();
        let resp = await fetch(`https://localhost:7086/api/quotes/tag/${tagName}`, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let quotesByTag = await resp.json();

            if (quotesByTag.length > 0) {

                for (let i = 0; i < quotesByTag.length; i++) {

                    let listItem = $(' </br> <li>');

                    listItem.append('(ID: ' + quotesByTag[i].quoteId + ') </br> <strong> The quote content: </strong> ' + quotesByTag[i].content + ' </br>  <strong> Author: </strong>' + quotesByTag[i].author
                        + '. </br> <strong>Likes: </strong>' + quotesByTag[i].likes + '. </br> <strong>Tags: </strong> #');

                    for (let j = 0; j < quotesByTag[i].tagNames.length; j++) {

                        listItem.append('' + quotesByTag[i].tagNames[j]);

                        if (j < quotesByTag[i].tagNames.length - 1) {
                            listItem.append(', #');
                        }
                    }

                    $('#quotes').append(listItem);
                    $('#quotes').append('</br>');
                }
            }
            else {

                $('#quotes').empty();
                _listItemsMsg.text('There isn\'t any quote by that tag. Use the form to add one.');
                _listItemsMsg.fadeOut(10000);
            }
            allQuotesClickListener();

        }
        else {
            _listItemsMsg.text('There was a problem loading the quote.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }
    });


    //a function to get all tags
    let loadTags = async function () {
        let resp = await fetch(_tagsUrl, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let tags = await resp.json();

            if (tags.length > 0) {
                otherItemsList.append(heading.text('All Tags'));

                // Loop through the tags array and append the details to the list 
                for (let i = 0; i < tags.length; i++) {

                    otherItemsList.append(` <div> <li>  ${tags[i].tagName} <a class="editTag" data-id="${tags[i].tagId}"  data-name="${tags[i].tagName}">Edit</a> </li> </div>  `);
                }
                otherItemsList.append(`
                       </br>
                       <div id="tagInput"> 
                           <h5> Edit Tag </h5>
                           <input type="text" id="tagName" name="tagName" class="form-control" />
                           </br> <button type="button" id="updateTagBtn" class="btn btn-primary">Update Tag</button>
                       </div>
                `);
                $('#tagInput').hide();
                otherItemsList.append('</br>  <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button> ');

                // Add a click event listener to the all quote button and edit tag button
                allQuotesClickListener();
                $('.editTag').on('click', async function () {
                    let tagId = $(this).data('id');
                    let tagName = $(this).data('name');

                    $('#updateTagBtn').data('tagId', tagId);
                    $('#tagName').val(tagName);
                    $('#tagInput').show();
                });

                $('#updateTagBtn').on('click', async function () {
                    // Retrieve the stored tag ID
                    let tagId = $(this).data('tagId');
                    let updatedTagName = $('#tagName').val();


                    try {
                        let response = await fetch(_tagsUrl + '/update/' + tagId, {
                            mode: "cors",
                            method: "POST",
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ tagName: updatedTagName })
                        });

                        if (response.ok) {
                            $('#tagName').val('');
                            _listItemsMsg.text('Tag was updated successfully.');
                            _listItemsMsg.fadeOut(10000);
                        }
                        else {
                            _listItemsMsg.text('Tag was not updated.');
                            _listItemsMsg.fadeOut(10000);
                        }
                    } catch (error) {
                        console.log(error);
                    }
                });
            }
            else {
                _listItemsMsg.text('There aren\'t any tags.');
                _listItemsMsg.attr('class', 'text-danger');
                _listItemsMsg.fadeOut(10000);
            }

        }
        else {
            _listItemsMsg.text('There was a problem loading the tags.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }
    };


    //a function to get most liked quotes
    let mostLikedQuotes = async function (count) {
        let resp = await fetch(`https://localhost:7086/api/quotes/most-liked?count=${count}`, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let mostLikedQuotes = await resp.json();

            if (mostLikedQuotes.length > 0) {
                otherItemsList.append(heading.text('Most Liked Quotes'));

                // Loop through the quotes array and append the details to the list 
                for (let i = 0; i < mostLikedQuotes.length; i++) {

                    let listItem = $('<li>');

                    listItem.append('(ID: ' + mostLikedQuotes[i].quoteId + ') </br> <strong> The quote content: </strong> ' + mostLikedQuotes[i].content + ' </br>  <strong> Author: </strong>' + mostLikedQuotes[i].author
                        + '. </br> <strong>Likes: </strong>' + mostLikedQuotes[i].likes + '. </br> <strong>Tags: </strong> #');

                    for (let j = 0; j < mostLikedQuotes[i].tagNames.length; j++) {

                        listItem.append('' + mostLikedQuotes[i].tagNames[j]);

                        if (j < mostLikedQuotes[i].tagNames.length - 1) {
                            listItem.append(', #');
                        }
                    }

                    otherItemsList.append(listItem);
                    otherItemsList.append('</br>');
                }

                otherItemsList.append(' <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button> </br> </br>');


                // Add a click event listener to the quote links
                allQuotesClickListener();
            }
            else {
                _listItemsMsg.text('There aren\'t any tags.');
            }

        }
        else {
            _listItemsMsg.text('There was a problem loading the tags.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }
    };

    //a click event listener to add a quote
    $('#addQuoteBtn').click(async function () {
        // Get user's input and use it to create a new quote object:
        try {
            let newQuote = {
                content: $('#quoteContent').val(),
                author: $('#quoteAuthor').val()
            }

            let resp = await fetch(_quotesUrl, {
                mode: "cors",
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newQuote)
            });


            if (resp.ok) {
                console.log('add quote successful');
                _addNewItemMsg.text('The new quote was added successfully!');
                _addNewItemMsg.attr('class', 'text-success');
                $('#quoteContent').val(' ');
                $('#quoteAuthor').val(' ');
                loadQuotes();
            } else {
                _addNewItemMsg.text('Hmmm, there was a problem adding a new quote.');
                _addNewItemMsg.attr('class', 'text-danger');
            }
            _addNewItemMsg.fadeOut(10000);
        } catch (error) {
            Console.WriteLine("There was an error adding a new quote " + error);
        }

    });


    //a click event listener to edit a quote
    $(document).on('click', '.editQuoteBtn', async function () {
        const editQuoteId = $(this).data('quoteid');

        quoteForm.hide();
        editQuoteForm.show();
        editQuoteForm.append(
            `<h4 id="quoteHeading">Edit Quote: </h4>
          <form>
            <div class="form-group">
                <label for="editQuoteContent">Content:</label>
                <textarea type="text" id="editQuoteContent" name="editQuoteContent" class="form-control"> </textarea>
            </div>
            
            </br>

            <div class="form-group">
                <label for="editQuoteAuthor">Author:</label>
                <input type="text" id="editQuoteAuthor" name="editQuoteAuthor" class="form-control" />
            </div>

            </br>

            <button type="button" id="saveQuoteBtn" data-id="${editQuoteId}" class="btn btn-primary">Save Quote</button>
          </form>
            `);

        let resp = await fetch(`https://localhost:7086/api/quotes/${editQuoteId}`, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            let quote = await resp.json();

            if (quote != null) {
                $('#editQuoteContent').val(quote.content),
                    $('#editQuoteAuthor').val(quote.author)
            }
            else {
                _addNewItemMsg.text('Hmmm, there was a problem somewhere');
                _addNewItemMsg.attr('class', 'text-danger');
            }
        } else {
            _addNewItemMsg.text('Hmmm, there was a problem finding that quote.');
            _addNewItemMsg.attr('class', 'text-danger');
        }
        _addNewItemMsg.fadeOut(10000);

    });

    //save button
    $(document).on('click', '#saveQuoteBtn', async function () {
        let editQuoteId = $(this).data('id');
        console.log(editQuoteId);
        let updatedQuote = {
            content: $('#editQuoteContent').val(),
            author: $('#editQuoteAuthor').val()
        }
        try {

            let resp = await fetch(_quotesUrl + '/edit/' + editQuoteId, {
                mode: "cors",
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedQuote)
            });

            if (resp.ok) {
                console.log('edit quote successful!');
                $('#editQuoteContent').val(' ');
                $('#editQuoteAuthor').val(' ');
                editQuoteForm.hide();
                editQuoteForm.empty();
                quoteForm.show();
                loadQuotes();
                _addNewItemMsg.text('The quote was updated successfully');
            }
            else {
                _addNewItemMsg.text('Hmmm, there was a problem somewhere');
            }
        } catch (error) {
            console.log('There was an error: ' + error);
        }

    });
    //a click event listener to tag a quote
    $(document).on('click', '.tagQuoteBtn', async function () {

        const quoteId = $(this).data('quoteid');

        //we're going to get the quote by that id 
        let resp = await fetch(`https://localhost:7086/api/quotes/${quoteId}`, {
            mode: 'cors'
        });

        if (resp.status === 200) {
            const quote = await resp.json();

            if (quote != null) {

                _quoteItemsList.hide();
                otherItemsList.show();
                otherItemsList.empty();

                //show the details of the quote
                otherItemsList.append('<strong> The quote content: </strong> ' + quote.content + ' </br>  <strong> Author: </strong>' + quote.author
                    + '. </br> <strong>Tags: </strong> <i> #');

                for (let j = 0; j < quote.tagNames.length; j++) {

                    otherItemsList.append('' + quote.tagNames[j]);

                    if (j < quote.tagNames.length - 1) {
                        otherItemsList.append(', #');
                    }
                }

                otherItemsList.append('</i>' +
                    ' <p> Enter the name of the tag you want to add: </p> '
                    + ' <input type="text" id="tagName" name="tagName" class="form-control" list="tagSuggestions"/>'
                    + ' <datalist id="tagSuggestions"></datalist>'
                    + ' <button type="button" id="addTagBtn" class="btn btn-primary">Add a Tag</button> </br> </br>'
                    + ' <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button> </br> </br>');

                autocomplete();


                // Add a click event listener to the "Add Tag" button
                $('#addTagBtn').on('click', async function () {
                    const addedTag = $('#tagName').val();
                    // Perform validation and add tag logic here
                    if (addedTag) {
                        // Example: Output the added tag
                        console.log(`Added Tag: ${addedTag}`);
                        // Add your logic to associate the tag with the quote or perform other actions
                        let response = await fetch(`https://localhost:7086/api/quotes/${quoteId}/tagQuote`, {
                            method: 'POST',
                            mode: 'cors',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ tagName: addedTag }),
                        });

                        if (response.ok) {

                            console.log('successfully added tag to quote');
                            _listItemsMsg.text('Tag added successfully.');
                            _listItemsMsg.attr('class', 'text-success');
                            _listItemsMsg.fadeOut(10000);

                            _quoteItemsList.hide();
                            otherItemsList.show();
                            otherItemsList.empty();
                            //show the details of the quote
                            otherItemsList.append('<strong> The quote content: </strong> ' + quote.content + ' </br>  <strong> Author: </strong>' + quote.author
                                + '. </br> <strong>Tags: </strong> <i> #');

                            for (let j = 0; j < quote.tagNames.length; j++) {

                                otherItemsList.append('' + quote.tagNames[j]);

                                if (j < quote.tagNames.length - 1) {
                                    otherItemsList.append(', #');
                                }
                            }

                            otherItemsList.append('</i>' +
                                '</br> <button type="button" id="allQuotesBtn" class="btn btn-primary">View all Quotes</button> </br> </br>');

                        } else {
                            const errorData = await response.json();
                            console.error(`Failed to tag quote with ID ${quoteId}. Server error: ${errorData}`);
                        }
                        // Clear the tag input and suggestions
                        $('#tagName').val('');
                        $('#tagSuggestions').empty();

                        allQuotesClickListener();

                    } else {
                        console.log('Invalid input. Please enter a tag.');
                    }
                });


            }
            else {
                _listItemsMsg.text('There isn\'t any quote by that id. Use the form to add one.');
            }

            allQuotesClickListener();
        }
        else {
            _listItemsMsg.text('There was a problem loading the quote.');
            _listItemsMsg.attr('class', 'text-danger');
            _listItemsMsg.fadeOut(10000);
        }

    });

    function autocomplete() {
        // Add autocomplete functionality for the tag input
        $('#tagName').on('input', updateTagSuggestions);

        // get the tags
        const fetchAvailableTags = async () => {
            const response = await fetch('https://localhost:7086/api/tags');
            const data = await response.json();

            return data; // No need to convert to an array
        };

        // Function to update tag suggestions
        async function updateTagSuggestions() {
            const inputText = $('#tagName').val().toLowerCase();
            const availableTagsPromise = fetchAvailableTags(); // Note: no 'await' here

            // Use .then() to handle the promise
            availableTagsPromise.then(availableTags => {
                // Clear existing suggestions
                $('#tagSuggestions').empty();

                // Add matching tags to the datalist
                availableTags.forEach(tag => {

                    if (tag.tagName.toLowerCase().includes(inputText)) {
                        $('#tagSuggestions').append(`<option value="${tag.tagName}" data-tagId="${tag.tagId}">`);

                    }
                });
            });
        }
    }


    //a click event listener to like a quote
    $(document).on('click', '#likeQuoteBtn', async function () {
        let quoteId = $(this).data('quoteid');
        // Get user's input and use it to create a new quote object:
        let response = await fetch(`https://localhost:7086/api/quotes/likes/${quoteId}`, {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json'
            },
        });
        console.log(response);
        if (response.ok) {
            const updatedLikes = await response.json();
            loadQuotes();
        } else {
            console.error(`Failed to like quote with ID ${quoteId}.`);
        }

    });



    quoteByIdClickListener();

    loadQuotes();
    allTagsClickListener();
    mostLikedClickListener();

    setInterval(loadQuotes, 1000);

});
