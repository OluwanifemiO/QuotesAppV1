﻿namespace QuotesApp.Models
{
    public class QuoteInfo
    {
        public int QuoteId { get; set; }
        public string? Content {  get; set; }

        public string? Author { get; set; }

        public int? Likes { get; set; }

        public ICollection<string>? TagNames { get; set; }
    }
}
