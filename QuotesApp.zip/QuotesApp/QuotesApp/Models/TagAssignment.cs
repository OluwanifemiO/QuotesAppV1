﻿namespace QuotesApp.Models
{
    public class TagAssignment
    {
        //composite keys:
        public int QuotesId { get; set; }
        public int TagsId { get; set; }

        //navigation properties
        public Quote? Quote { get; set; }

        public Tag? Tag { get; set; }
    }
}
