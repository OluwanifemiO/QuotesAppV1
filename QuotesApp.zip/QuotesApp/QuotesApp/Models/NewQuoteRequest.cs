﻿namespace QuotesApp.Models
{
    public class NewQuoteRequest
    {
        public string Content {  get; set; }

        public string? Author { get; set; }

        public int Likes {  get; set; }

        //public string TagName {  get; set; }

    }
}
